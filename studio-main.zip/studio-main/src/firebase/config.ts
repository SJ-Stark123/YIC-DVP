export const firebaseConfig = {
  "projectId": "studio-5146134596-cff7d",
  "appId": "1:842565908:web:98b86cf43adce83735da01",
  "apiKey": "AIzaSyBHaAIlGI_RZDaNgalJwneVLbiRLCF8Fg0",
  "authDomain": "studio-5146134596-cff7d.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "842565908"
};
