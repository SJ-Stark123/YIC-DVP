import { config } from 'dotenv';
config();

import '@/ai/flows/image-suggestion-for-content.ts';